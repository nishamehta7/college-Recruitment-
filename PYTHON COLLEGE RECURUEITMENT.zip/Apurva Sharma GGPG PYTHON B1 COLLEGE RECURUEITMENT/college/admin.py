from django.contrib import admin

# Register your models here.
from .models import *

class contactAdmin(admin.ModelAdmin):
    list_display=("name","mobile","email","message")
admin.site.register(contact,contactAdmin)

class profileAdmin(admin.ModelAdmin):
    list_display=("name","dob","email","password","mobno","gender","Address","qualification","course","year","resume","picture")
admin.site.register(registration,profileAdmin)

class categoryAdmin(admin.ModelAdmin):
    list_display = ("clogo","tname","link","city")
admin.site.register(category,categoryAdmin)

class vacancyAdmin(admin.ModelAdmin):
    list_display=("cid","designation","vacant","desc","skill","salary","vdate")
admin.site.register(vacancy,vacancyAdmin)

class applyjobAdmin(admin.ModelAdmin):
    list_display=("jid","sid")
admin.site.register(applyjob,applyjobAdmin)

"""class companiesAdmin(admin.ModelAdmin):
    list_display = ("cname","cpic","cdate","curl","ccity")
admin.site.register(companies,companiesAdmin)"""

class myprofileAdmin(admin.ModelAdmin):
    list_display = ("name","course","branch","year")
admin.site.register(myprofile,myprofileAdmin)

class studentloginadmin(admin.ModelAdmin):
    list_display = ("uname","password")
admin.site.register(studentlogin,studentloginadmin)
