from django.db import models

# Create your models here.
class contact(models.Model): #inheriting Model class present in models module
    name=models.CharField(max_length=100) #name is field name
    email=models.CharField(max_length=120)
    mobile=models.CharField(max_length=20)
    message=models.CharField(max_length=600)

    def __str__(self):
        return self.name

"""class register(models.Model):
    name=models.CharField(max_length=120)
    mobile=models.CharField(max_length=20)
    email=models.EmailField(max_length=80,primary_key=True)
    passwd=models.CharField(max_length=100)
    address=models.TextField(max_length=2000)
    ppic=models.ImageField(upload_to='static/profile')

    def __str__(self):
        return self.name"""

class category(models.Model):
    clogo=models.ImageField(upload_to='static/company',default="")
    tname=models.CharField(max_length=60)
    link=models.CharField(max_length=30)
    city=models.CharField(max_length=40)

    def __str__(self):
        return self.tname
"""class companies(models.Model):
    cname=models.CharField(max_length=40)
    cpic=models.ImageField(upload_to='static/companies',default="")
    cdate=models.DateField()
    curl=models.CharField(max_length=500)
    ccity=models.CharField(max_length=48)
    def __str__(self):
        return self.cname"""
    
class registration(models.Model):
    name=models.CharField(max_length=100)
    dob=models.CharField(max_length=25)
    email=models.CharField(max_length=200)
    password=models.CharField(max_length=50)
    mobno=models.CharField(max_length=30)
    gender=models.CharField(max_length=30)
    Address=models.CharField(max_length=50)
    qualification=models.CharField(max_length=200)
    course=models.CharField(max_length=100)
    year=models.CharField(max_length=100)
    resume=models.ImageField(upload_to='static/resume',default="")
    picture=models.ImageField(upload_to='static/profile',default="")

    def __str__(self):
        return self.name

class vacancy(models.Model):

    cid=models.ForeignKey(category,on_delete=models.CASCADE)
    jid=models.IntegerField(max_length=30)
    designation=models.CharField(max_length=200)
    vacant=models.CharField(max_length=10)
    desc=models.CharField(max_length=200)
    skill=models.CharField(max_length=200)
    salary=models.CharField(max_length=100)
    vdate=models.DateField()

    def __str__(self):
        return self.designation

class applyjob(models.Model):
    jid=models.IntegerField()
    sid=models.CharField(max_length=200)

class myprofile(models.Model):
    name=models.CharField(max_length=50)
    course=models.CharField(max_length=50)
    branch=models.CharField(max_length=50)
    year=models.CharField(max_length=50)

    def __str__(self):
        return self.name

class studentlogin(models.Model):
    uname=models.CharField(max_length=40)
    password=models.CharField(max_length=50)

    def __str__(self):
        return self.uname