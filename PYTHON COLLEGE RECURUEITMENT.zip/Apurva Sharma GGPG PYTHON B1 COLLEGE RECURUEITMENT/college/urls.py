from django.urls import path
from . import views

urlpatterns=[
    path('',views.home),
    path('index/',views.home),
    path('aboutus/',views.aboutus),
    path('contactus/',views.contactus),
    path('vacancy/',views.newvacancy),
    path('jobs/',views.jobs),
    path('placement/',views.placement),
    path('register/',views.registrations),
    path('profile/',views.myprofile),
    path('login/',views.studentlogin),
]