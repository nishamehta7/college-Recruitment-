from django.db import connection
from django.shortcuts import render
from .models import *
from django.http import HttpResponse
# Create your views here.
def home(request):
    cdata = category.objects.all().order_by('-id')
    vdetail=vacancy.objects.all().order_by('-jid')[0:4]# end-1
    return render(request, 'college/index.html', {"data": cdata,"vdetail":vdetail})


def aboutus(request):
    return render(request,'college/aboutus.html')

def contactus(request):
    status=False #variable status
    if request.method=='POST':
        Name=request.POST.get("name","") #value of name attribute of input tag
        Contact=request.POST.get("mobile","")
        Email=request.POST.get("email","")
        Message=request.POST.get("msg","")
        x=contact(name=Name,email=Email,mobile=Contact,message=Message) #field names
        x.save()
        status=True
        #return HttpResponse("<script>alert('Thanks for enquiry..!');window.location.href='/user/contactus/'</script>")
    return render(request,'college/contactus.html',{'S':status})

def newvacancy(request):
    if (request.GET.get('jid') is not None):
        if (request.session.get('stu')):
            jid=request.GET.get('jid')
            userid=request.session.get('stu')
            a=applyjob(jid=jid,sid=userid)
            a.save()
            return HttpResponse(
                "<script>alert('You have applied successfully..!');window.location.href='/college/login/'</script>")
        else:
            return HttpResponse(
                "<script>alert('Please Log In First.!');window.location.href='/college/login/'</script>")
    if(request.GET.get('cid') is not None):
        cid=request.GET.get('cid')
        vdetail=vacancy.objects.filter(cid=cid)
    else:
        vdetail = vacancy.objects.all().order_by('-jid')
    cdata = category.objects.all().order_by('-id')
    return render(request,'college/newvacancy.html',{"data": cdata,"vdetail":vdetail})

def jobs(request):
    if request.session.get('stu'):
        return render(request,'college/jobs.html')
    else:
        return HttpResponse(
            "<script>alert('Please Log In first to see list.!');window.location.href='/college/login/'</script>")

def placement(request):
    return render(request,'college/placement.html')

def registrations(request):
    if request.method=='POST':
        name=request.POST.get("name","")
        dob=request.POST.get("dob","")
        email=request.POST.get("email","") #value of name in brackets
        course=request.POST.get("course","")
        year=request.POST.get("year","")
        mobile=request.POST.get("mobile","")
        qualification=request.POST.get("qualification","")
        gender=request.POST.get("a","")
        resume=request.FILES['resume']
        password=request.POST.get("passwd","")
        address=request.POST.get("address","")
        picname=request.FILES['profile']
        registration(name=name,email=email,mobno=mobile,password=password,Address=address,picture=picname,dob=dob,course=course,year=year,qualification=qualification,
                     gender=gender,resume=resume).save()
        return HttpResponse("<script>alert('You are Registered successfully !');window.location.href='college/registration'</script>")
    return render(request,'college/registration.html')

def myprofile(request):
    if (request.session.get('stu')):
        id=request.session.get('stu')
        userdata=registration.objects.filter(email=id)[0:1]
        #registration is table
        #email is model field
        return render(request, 'college/myprofile.html',{"userdata":userdata})
    else:
        return HttpResponse(
            "<script>alert('Please Log In first !');window.location.href='college/login'</script>")


def studentlogin(request):
    if request.method=='POST':
        uname=request.POST.get('uname')
        password=request.POST.get('password')
        res=registration.objects.filter(email=uname, password=password)
        if res:
            request.session['stu']=uname
            return HttpResponse(
                "<script>alert('Logged In Successfully !');window.location.href='/college/login'</script>")
    return render(request,'college/studentlogin.html')

